# PRD.md

# Tamasha Music Archive Platform Product Requirements Document

## Product Summary

Tamasha is a music archive and streaming platform designed to preserve, organize, stream, enrich, and monetize African music collections.

It supports:

- music archival storage
- staff-assisted metadata cleanup
- artist ownership assignment
- listener streaming
- duplicate detection
- adaptive bitrate streaming
- Skiza clip preparation
- S3/R2 sync into MongoDB
- email notifications
- backup to secondary storage
- analytics dashboards

---

# Product Goals

## Primary Goals

1. Preserve original uploaded music safely.
2. Upload large folders directly to S3/R2.
3. Sync storage objects into MongoDB metadata.
4. Allow admin/staff to manage tracks and artists.
5. Allow artists to claim and view their music.
6. Allow listeners to stream, like, favorite, and discover music.
7. Detect exact and near duplicates.
8. Generate bitrate variants for streaming.
9. Support Skiza clip preparation for Safaricom services.
10. Maintain backups to secondary S3-compatible storage.

---

# Users and Permissions

## Admin

Admin has full system access.

Admin can:

- view whole system statistics
- manage users
- create staff accounts
- approve/reject artists
- assign tracks to artists
- edit all metadata
- upload/update artwork
- trigger Skiza workflow
- approve Skiza exports
- trigger on-demand S3 sync
- configure scheduled sync
- view sync jobs
- view backup jobs
- view storage stats
- view listener analytics
- view audit logs
- resolve duplicates
- export reports

---

## Staff

Staff manages operational archive work.

Staff can:

- upload music
- view own uploads
- edit assigned tracks
- rename tracks
- upload artwork
- update artist details
- create Skiza clips
- submit Skiza clips for approval
- review duplicate suggestions
- view own activity

Staff cannot:

- manage admin accounts
- delete raw music permanently
- assign global permissions
- approve their own sensitive actions unless allowed

---

## Artist

Artist users manage their own assigned catalog.

Artist can:

- view assigned music
- edit profile
- upload profile image
- view analytics
- request music ownership
- submit correction requests
- upload new music for review

Artist cannot:

- see other artists' private analytics
- edit unassigned tracks
- approve ownership claims

---

## Listener / Guest

Listener can:

- stream public music
- search music
- like tracks
- favorite tracks
- create playlists when logged in
- follow artists
- view public artist pages

---

# Core Modules

## 1. Upload Module

### Requirements

- direct upload to S3/R2
- folder structure preservation
- retry support
- resume/skip-existing logic
- progress bar
- upload manifest
- terminal service support
- future browser upload support

### Uploader Service

Located in:

```text
Uploader/
```

Uploader is a terminal service that uploads directly to S3/R2.

---

## 2. S3/R2 Sync Module

### Purpose

MongoDB must stay synchronized with the main S3/R2 bucket.

### Sync Modes

- on-demand sync
- scheduled incremental sync
- scheduled full sync
- integrity scan

### Suggested Schedule

```text
Every 15 minutes: incremental new-object sync
Every 1 hour: metadata reconciliation
Every night at 2 AM: full bucket scan
Every week: deep checksum/integrity scan
```

### Sync Features

- detect new objects
- create track records
- update changed metadata
- mark missing objects as unavailable
- calculate total storage usage
- queue metadata extraction
- queue duplicate detection
- queue transcoding
- queue artwork extraction

### Safety Rules

- do not auto-delete Mongo records
- do not auto-delete S3 objects
- sync must be idempotent
- failed sync jobs must retry
- all sync runs must be logged

---

## 3. Music Metadata Module

### Track Metadata

Store:

- title
- artist
- album
- year
- genre
- duration
- bitrate
- format
- file size
- S3 bucket
- S3 key
- original path
- sha256 hash
- artwork key
- assigned artist ID
- visibility status

---

## 4. Duplicate Detection Module

### Exact Detection

Use:

- SHA256
- file size
- duration

### Near Duplicate Detection

Use:

- audio fingerprinting
- title similarity
- artist similarity
- album similarity
- duration similarity

### Admin/Staff Workflow

- duplicate group created
- staff reviews
- canonical track selected
- duplicates linked
- no automatic deletion

---

## 5. Streaming Module

### Requirements

- signed URLs
- bitrate variants
- HLS support
- listener analytics
- CDN-compatible delivery

### Bitrates

- 64kbps
- 128kbps
- 192kbps
- 320kbps
- original when allowed

---

## 6. Skiza Module

### Purpose

Allow admin/staff to prepare tracks for Safaricom Skiza services.

### User Flow

1. admin/staff opens track page
2. clicks `Sync Skiza`
3. editor opens
4. user cuts/selects clip
5. user previews clip
6. user adds Skiza metadata
7. user saves draft
8. user submits for approval
9. admin approves
10. worker exports Skiza file
11. system syncs/submits to Safaricom integration when available

### Clip Metadata

Store:

- source track ID
- start time
- end time
- duration
- output file
- creator staff ID
- approval status
- export status
- provider sync status
- provider reference ID

### Statuses

```text
draft
pending_review
approved
rejected
exporting
exported
submitted_to_safaricom
accepted
failed
```

---

## 7. Email Notification Module

### Email Types

Authentication:

- verify email
- reset password
- suspicious login

Artist:

- artist account pending
- artist approved
- artist rejected
- music assigned
- ownership claim approved
- ownership claim rejected

Staff:

- upload complete
- upload failed
- duplicate detected
- metadata review assigned
- Skiza review required

Admin:

- daily summary
- backup failed
- sync failed
- artist claim pending
- Skiza approval pending
- storage threshold warning
- worker failure

System:

- scheduled sync completed
- scheduled sync failed
- backup completed
- backup failed
- transcoding failed

---

## 8. Analytics Module

### Track Metrics

- streams
- likes
- favorites
- shares
- playlist additions
- completion rate
- skip rate
- replay count

### Listener Metadata

- IP address
- user agent
- browser
- device
- OS
- approximate location
- session ID
- bitrate used
- listening duration

### Artist Metrics

- total streams
- monthly listeners
- top tracks
- listener countries
- likes/favorites
- playlist additions

---

## 9. Backup Module

### Purpose

Maintain a secondary copy of music and metadata.

### Requirements

- backup primary S3/R2 to secondary S3
- scheduled backup
- on-demand backup
- backup manifest
- checksum verification
- restore tracking
- alert on failure

---

# Recommended MongoDB Collections

- users
- artists
- tracks
- albums
- uploads
- object_sync_records
- track_versions
- duplicate_groups
- activities
- listening_events
- likes
- favorites
- playlists
- skiza_clips
- skiza_jobs
- transcoding_jobs
- email_events
- backup_jobs
- sync_jobs
- storage_stats
- audit_logs

---

# MVP Scope

## Phase 1

- auth
- admin dashboard
- staff dashboard
- uploader
- S3/R2 sync
- Mongo track records
- basic search
- basic streaming
- duplicate hash detection

## Phase 2

- artist onboarding
- artist assignment
- likes/favorites
- listener analytics
- artwork management
- email notifications

## Phase 3

- Skiza editor
- Skiza export workflow
- adaptive bitrate streaming
- backup service
- advanced duplicate detection

## Phase 4

- recommendations
- advanced analytics
- public APIs
- mobile app
- monetization
- rights management
