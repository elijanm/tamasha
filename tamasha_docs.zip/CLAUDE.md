# CLAUDE.md

# Tamasha Music Archive Platform

Tamasha is a Docker-first monorepo platform for preserving, managing, enriching, streaming, and monetizing African music archives.

The platform includes:

- FastAPI backend
- React/Vite frontend
- Celery workers
- standalone terminal uploader
- Cloudflare R2 / S3-compatible storage
- MongoDB metadata database
- Redis queues/cache
- background sync workers
- Skiza preparation workflow for Safaricom services

---

# Monorepo Structure

```text
tamasha/
│
├── README.md
├── CLAUDE.md
├── .gitignore
├── .env
├── .env.example
├── Makefile
│
├── docs/
│   ├── PRD.md
│   ├── architecture.md
│   ├── roles-and-permissions.md
│   ├── skiza-workflow.md
│   ├── sync-schedule.md
│   ├── emails.md
│   ├── streaming.md
│   ├── duplicate-detection.md
│   ├── analytics.md
│   ├── backup-strategy.md
│   └── deployment.md
│
├── app.backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   └── app/
│       ├── main.py
│       ├── config.py
│       ├── db/
│       ├── models/
│       ├── routes/
│       ├── services/
│       ├── schemas/
│       ├── events/
│       ├── utils/
│       └── tests/
│
├── app.ui-reactjs/
│   ├── Dockerfile
│   ├── package.json
│   ├── vite.config.ts
│   └── src/
│       ├── api/
│       ├── hooks/
│       ├── store/
│       ├── routes/
│       ├── layouts/
│       ├── pages/
│       ├── components/
│       ├── styles/
│       ├── utils/
│       └── types/
│
├── app.worker/
│   ├── Dockerfile
│   ├── requirements.txt
│   └── worker/
│       ├── celery_app.py
│       ├── config.py
│       ├── tasks/
│       ├── services/
│       ├── queues/
│       └── utils/
│
├── Uploader/
│   ├── Dockerfile
│   ├── uploader.py
│   ├── requirements.txt
│   ├── .env.example
│   ├── README.md
│   ├── install.bat
│   ├── build.bat
│   ├── build.sh
│   ├── uploader/
│   ├── logs/
│   ├── manifests/
│   └── dist/
│
├── infra/
│   ├── docker/
│   │   ├── docker-compose.yml
│   │   ├── mongodb/
│   │   ├── redis/
│   │   ├── nginx/
│   │   ├── monitoring/
│   │   └── minio/
│   ├── nginx/
│   ├── monitoring/
│   └── scripts/
│
├── storage/
│   ├── ffmpeg/
│   ├── waveform/
│   ├── transcoding/
│   ├── skiza/
│   └── backup/
│
└── shared/
    ├── constants/
    ├── schemas/
    ├── events/
    ├── types/
    └── utils/
```

---

# Services

## app.backend

FastAPI API service.

Responsible for:

- authentication
- RBAC authorization
- user management
- artist management
- track metadata
- album metadata
- playlists
- likes/favorites
- streaming APIs
- signed URLs
- S3/R2 object references
- Skiza workflow APIs
- analytics APIs
- admin dashboards
- staff dashboards
- audit logs
- sync job orchestration
- backup job orchestration

---

## app.ui-reactjs

React + Vite frontend.

Responsible for:

- admin dashboard
- staff dashboard
- artist portal
- listener portal
- music player
- analytics views
- upload management
- metadata editing
- artwork editing
- Skiza sync button/workflow launcher
- duplicate management UI
- backup status UI
- sync schedule UI

---

## app.worker

Celery worker service.

Responsible for:

- email notifications
- metadata extraction
- S3-to-Mongo sync
- transcoding
- bitrate sample generation
- waveform generation
- duplicate detection
- hash calculation
- Skiza export/preparation
- backup jobs
- analytics aggregation
- scheduled maintenance
- failed job retry

---

## Uploader

Standalone terminal service.

Responsible for:

- direct R2/S3 upload
- folder watching
- resume/skip-existing logic
- progress bar
- upload manifests
- basic hashing
- preserving folder structure
- safe memory-bounded parallel uploads

Uploader should not be responsible for full metadata governance. It uploads raw archive files safely. The backend/worker sync process later indexes objects into MongoDB.

---

# Docker

Docker compose lives under:

```text
infra/docker/docker-compose.yml
```

Run:

```bash
docker compose -f infra/docker/docker-compose.yml up --build
```

---

# User Roles

## Admin

Admin has complete system visibility and control.

Admin can:

- view whole-system dashboard
- manage all users
- create staff accounts
- approve artist accounts
- assign music to artists
- merge duplicate artists
- merge duplicate tracks
- view all uploads
- view all staff activity
- view all artist activity
- view all listener metrics
- edit any metadata
- upload/update track artwork
- upload/update artist images
- trigger S3-to-Mongo sync
- schedule sync jobs
- run Skiza preparation workflows
- approve Skiza-ready tracks
- manage backup jobs
- view backup status
- view total storage used
- view stream analytics
- view audit logs
- disable tracks
- publish/unpublish tracks
- ban users/IPs
- export reports

Admin dashboard must include:

- total tracks
- total artists
- total albums
- total users
- total storage used
- storage growth
- top streamed tracks
- top liked tracks
- top favorited tracks
- top artists
- most active staff
- duplicate percentage
- pending artist claims
- pending Skiza jobs
- failed sync jobs
- backup health
- S3 sync health
- queue health
- daily/monthly listeners
- bandwidth usage

---

## Staff

Staff are operational users who maintain the archive.

Staff can:

- upload music
- view their own uploads
- view assigned uploads
- edit metadata for permitted tracks
- rename tracks
- upload artwork
- upload artist images
- update artist details
- run duplicate checks for assigned music
- prepare tracks for review
- open Skiza edit workflow
- cut Skiza clips
- submit Skiza versions for approval
- view their own activity log
- view processing status for their uploads

Staff dashboard must include:

- files uploaded by staff member
- metadata edits performed
- artwork changes performed
- Skiza jobs created
- pending tasks
- failed uploads
- duplicate warnings
- recent actions

Every staff action must be audit logged.

---

## Artist

Artist users only see music assigned to them.

Artist can:

- view assigned tracks
- view assigned albums
- update artist profile
- upload profile images
- upload biography
- request correction of metadata
- request ownership of unassigned tracks
- view stream counts
- view likes/favorites
- view listener geography
- view top tracks
- optionally upload new music for review

Artist onboarding flow:

1. artist creates account
2. account status becomes `pending_artist_verification`
3. artist may search/request music ownership
4. admin/staff reviews claim
5. admin assigns approved tracks/albums
6. artist gains access to assigned catalog

Artist must not directly see music assigned to other artists.

---

## Guest / Listener

Guest/listener can:

- browse public music
- search tracks/artists/albums
- stream music
- like tracks
- favorite tracks
- create playlists if logged in
- follow artists
- share tracks
- view public artist pages

Listener analytics should track:

- IP address
- user agent
- device
- browser
- OS
- approximate location
- stream start
- stream duration
- completion percentage
- bitrate selected
- likes
- favorites
- playlist additions
- referrer
- session ID

Privacy note: analytics must be used responsibly and should comply with applicable privacy laws.

---

# Email Notification Types

## Authentication Emails

- account verification email
- password reset email
- login alert email
- suspicious login email

## Artist Emails

- artist account created
- artist verification pending
- artist account approved
- artist account rejected
- music assigned to artist
- ownership claim received
- ownership claim approved
- ownership claim rejected
- profile update approved
- new analytics report available

## Staff Emails

- staff account created
- task assigned
- upload completed
- upload failed
- duplicate detected
- metadata review required
- Skiza edit requested
- Skiza clip approved
- Skiza clip rejected

## Admin Emails

- daily system summary
- backup failure
- sync failure
- high duplicate warning
- worker queue failure
- storage threshold warning
- artist claim pending
- Skiza approval pending
- suspicious activity detected

## Listener Emails

- welcome email
- playlist created
- favorite artist new music alert
- password reset
- account security alert

## System Emails

- scheduled sync completed
- scheduled sync failed
- backup completed
- backup failed
- transcoding failed
- R2/S3 access error
- storage usage threshold reached

---

# S3/R2 to MongoDB Sync

The platform must maintain MongoDB metadata based on objects stored in the main S3/R2 bucket.

## Sync Modes

### On-demand Sync

Admin can trigger sync manually from dashboard.

Use cases:

- after large uploader run
- after migration
- after backup restore
- after metadata repair
- after direct S3 object changes

### Scheduled Sync

System can run sync automatically.

Recommended schedules:

- every 15 minutes for small incremental sync
- hourly object metadata sync
- nightly full reconciliation
- weekly deep integrity scan

Example Celery beat schedule:

```python
beat_schedule = {
    "sync-r2-incremental-every-15-minutes": {
        "task": "worker.tasks.sync_tasks.sync_r2_incremental",
        "schedule": 900,
    },
    "sync-r2-hourly-metadata": {
        "task": "worker.tasks.sync_tasks.sync_r2_metadata",
        "schedule": 3600,
    },
    "sync-r2-nightly-full": {
        "task": "worker.tasks.sync_tasks.sync_r2_full",
        "schedule": crontab(hour=2, minute=0),
    },
    "backup-nightly": {
        "task": "worker.tasks.backup_tasks.backup_primary_to_secondary",
        "schedule": crontab(hour=3, minute=0),
    },
}
```

## Sync Responsibilities

Sync worker must:

- list S3/R2 objects
- compare object key with MongoDB records
- create missing track records
- update changed object metadata
- mark missing objects as unavailable, not deleted
- calculate size totals
- detect new files
- queue metadata extraction
- queue duplicate detection
- queue transcoding
- queue artwork extraction
- preserve original object key
- preserve original upload path
- store bucket, key, etag, size, content type, last modified

## Sync Record Fields

Track object metadata should include:

```json
{
  "bucket": "tamasha-music",
  "key": "music/Duplicates/Franco/Franco_-_Mario.mp3",
  "original_key": "music/Duplicates/Franco/Franco_-_Mario.mp3",
  "size_bytes": 7340032,
  "etag": "...",
  "content_type": "audio/mpeg",
  "last_modified": "...",
  "sha256": "...",
  "sync_status": "synced",
  "availability": "available",
  "source": "r2_sync"
}
```

## Sync Safety Rules

- Never delete Mongo records automatically.
- Never delete S3/R2 objects automatically.
- Missing objects should be marked `missing_from_storage`.
- Changed objects should create a new version record.
- Failed sync jobs must be retryable.
- Sync must be idempotent.

---

# Skiza Workflow

Skiza workflow allows staff/admin to prepare music clips for Safaricom Skiza services.

## UI Behavior

When admin or staff clicks a music track, available actions include:

- View details
- Edit metadata
- Upload artwork
- Assign artist
- Check duplicates
- Open Skiza editor
- Generate bitrate samples
- Trigger transcoding
- Re-sync from S3
- View activity log

## Open Skiza Editor

Action name:

```text
Sync Skiza
```

When clicked:

1. frontend opens music edit interface
2. original audio is loaded through signed URL
3. user can cut/select a clip
4. user can preview clip
5. user can normalize audio
6. user can fade in/out
7. user can set Skiza title
8. user can set artist/provider metadata
9. user can save draft
10. user can submit for approval/export

## Skiza Clip Requirements

Each Skiza record should store:

- source track ID
- source S3 key
- clip start time
- clip end time
- duration
- output format
- output bitrate
- normalized loudness
- fade settings
- staff creator
- approval status
- exported file key
- Safaricom sync status
- external reference ID if available

## Skiza Statuses

```text
draft
pending_review
approved
rejected
exporting
exported
submitted_to_safaricom
accepted
failed
```

## Skiza Storage Layout

```text
/music/skiza/drafts/
/music/skiza/approved/
/music/skiza/exported/
/music/skiza/rejected/
```

## Skiza Worker Tasks

- generate clip
- normalize loudness
- convert format
- validate duration
- upload export to S3/R2
- send approval email
- send failure email
- submit/sync with Safaricom integration when available

## Safaricom Integration

The system should be designed with an integration boundary.

Do not hardcode Safaricom logic into the editor.

Use service abstraction:

```python
class SkizaProvider:
    def submit_clip(self, clip_id: str) -> ProviderResult:
        pass

class SafaricomSkizaProvider(SkizaProvider):
    def submit_clip(self, clip_id: str) -> ProviderResult:
        pass
```

---

# Bitrate Samples and Streaming

When music is requested or prepared for streaming, system should generate bitrate variants.

## Variants

- 64kbps preview
- 128kbps low
- 192kbps standard
- 320kbps high
- original/lossless when allowed

## Worker Tasks

- transcode track
- generate HLS playlist
- generate waveform
- extract duration
- extract audio metadata
- update MongoDB

## Storage Layout

```text
/music/raw/
/music/transcoded/{track_id}/64k/
/music/transcoded/{track_id}/128k/
/music/transcoded/{track_id}/192k/
/music/transcoded/{track_id}/320k/
/music/waveforms/{track_id}.json
/music/artwork/
```

---

# MongoDB Collections

Recommended collections:

- users
- roles
- artists
- tracks
- albums
- uploads
- object_sync_records
- track_versions
- duplicate_groups
- activities
- listening_events
- likes
- favorites
- playlists
- skiza_clips
- skiza_jobs
- transcoding_jobs
- email_events
- backup_jobs
- sync_jobs
- storage_stats
- audit_logs
- worker_failures

---

# Activity and Audit Logging

Every important action must be recorded.

Track:

- actor user ID
- actor role
- action type
- entity type
- entity ID
- old value
- new value
- IP address
- user agent
- timestamp

Examples:

- staff renamed track
- admin assigned artist
- worker detected duplicate
- artist claimed music
- listener liked track
- admin triggered sync
- staff created Skiza clip

---

# Backup Service

Backup worker should copy primary music objects to secondary S3-compatible storage.

## Backup Sources

Primary:

- Cloudflare R2

Secondary options:

- Backblaze B2
- Wasabi
- AWS S3 Glacier
- Linode Object Storage

## Backup Requirements

- scheduled backup
- on-demand backup
- checksum validation
- backup manifest
- restore manifest
- failed backup alerts
- total backed-up size
- backup lag metric

## Backup Statuses

```text
pending
running
completed
failed
partial
verified
```

---

# Duplicate Detection

Duplicate detection should use multiple methods.

## Exact Duplicates

- SHA256 hash
- object size
- duration

## Near Duplicates

- audio fingerprint
- title similarity
- artist similarity
- duration similarity
- waveform similarity

## Rules

- Never auto-delete duplicates.
- Create duplicate groups.
- Admin/staff reviews groups.
- Canonical track can be selected.
- Duplicate records remain linked.

---

# Recommended Development Principles

1. Preserve original archive.
2. Never delete raw music automatically.
3. Use reversible transformations.
4. Use audit logs for every change.
5. Keep workers idempotent.
6. Make sync jobs resumable.
7. Keep storage paths stable.
8. Use MongoDB as metadata index, not source of raw truth.
9. Use R2/S3 as raw object source of truth.
10. Track provenance for all metadata changes.

---

# AI Assistant Coding Rules

When generating code for this repo:

- follow existing monorepo structure
- use FastAPI for backend
- use React/Vite for frontend
- use Celery for workers
- use MongoDB for metadata
- use Redis for queues
- place docker compose under `infra/docker`
- preserve raw files
- never implement destructive delete as default
- include audit logging for admin/staff actions
- ensure workers are idempotent
- make jobs retryable
- use signed URLs for private media
- separate raw music from derived assets
